import { BrowserRouter, Route, Routes } from "react-router-dom";
import React,{lazy,Suspense} from "react";

const Products = lazy(() => import('./modules/Products'));
function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Suspense fallback = { <div className="spinner-border text-primary"/>}><Products/></Suspense>}></Route>
    </Routes>

    </BrowserRouter>
    
  );
}

export default App;
