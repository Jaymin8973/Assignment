import React, { useState, useEffect } from 'react'
import axios from 'axios'

function Products() {
  const [data, setData] = useState([]);
  useEffect(() => {
    fetch();
  }, []);

  const fetch = async () => {
    const res = await axios.get(`http://localhost:3000/products`);
    //console.log(res.data);
    setData(res.data);
  }

  return (

    <section className="service_section layout_padding">
      <div className="container ">
        <div className="heading_container heading_center">
          <h2> Our Product </h2>
        </div>

        <div className="row">
          {
            data.map((value) => {

              return (
                <div className="container mt-3 col-4">
                  <div className="card" style={{ width: 300 }}>
                    <img className="card-img-top" src={value.thumbnailUrl} alt="Card image" style={{ width: '100%' }} />
                    <div className="card-body">
                      <h4 className="card-title">{value.title}</h4>
                   
                      <a href="#" className="btn btn-primary">See Profile</a>
                    </div>
                  </div>
                </div>

              )
            })
          }


        </div>

      </div>
    </section>


  )
}

export default Products